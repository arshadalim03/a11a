package com.cg.iconnect.beans;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class IConnect 
{
	private static WebElement element = null; 
	static Actions action;
	
	@FindBy(how=How.ID,id="1")
	WebElement manageLeave;
	
	@FindBy(how=How.ID,id="6")
	WebElement applyLeave;
	
	@FindBy(how=How.NAME,name="IDToken1")
	WebElement username;
	
	@FindBy(how=How.NAME,name="IDToken2")
	WebElement password;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"content\"]/table/tbody/tr[4]/td[2]/table/tbody/tr[5]/td[2]/div/input")
	WebElement login;
	
	@FindBy(how=How.ID,id="submitleavebtn")
	WebElement applyLeaveSubmit;
	
	public void clickLogin() {
		login.click();
	}
	
	public void applyLeaveSubmit() {
		applyLeaveSubmit.submit();
	}
	public void clickManageLeave() {
		manageLeave.click();
	}
	
	public void clickApplyLeave() {
		applyLeave.click();
	}
	
	public String getUsername() {
		return username.getAttribute("value");
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public static WebElement errorStartDate(WebDriver driver) {
		WebElement ele = driver.findElement(By.id("ALStartDate-error"));
		return ele;
	}
	
	public static WebElement clarity(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[1]"))).click().build().perform();
		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_lnkClarity']"));
		return element;
	}

	public static WebElement teamForge(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[1]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_lnkSourceForge']"));
		return element;
	}
	public static WebElement teamX(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[1]"))).click().build().perform();
		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_lnkTeamx']"));
		return element;
	}
	public static WebElement fsSBU(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[1]"))).click().build().perform();

		element = driver.findElement(By.xpath("ctl00_cphMainContent_lnkKmportal"));
		return element;
	}
	public static WebElement itS(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[1]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_HyperLink1']"));
		return element;
	}
	public static WebElement fsSBUSales(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[1]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_lnkMarketing']"));
		return element;
	}
	public static WebElement fiona(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[1]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_HyperLink6']"));
		return element;
	}
	public static WebElement iQMS(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[1]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_HyperLink8']"));
		return element;
	}
	public static WebElement ICompass(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[1]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_HyperLink5']"));
		return element;
	}
	public static WebElement PSA(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[1]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_lnkProjectSetup']"));
		return element;
	}
	public static WebElement N2K(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[1]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_HyperLink3']"));
		return element;
	}
	public static WebElement fs_SBU_Service(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[2]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_lnkHelpdesk']"));
		return element;
	}
	public static WebElement mCBS(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[2]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_HyperLink17']"));
		return element;
	}
	public static WebElement classifieds(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[2]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_lnkClassifieds']"));
		return element;
	}
	public static WebElement oLC(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[2]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_lnkLibrary']"));
		return element;
	}
	public static WebElement egencia(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[2]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_hypEgencialink']"));
		return element;
	}
	public static WebElement webMail(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[2]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_lnkWebmail1']"));
		return element;
	}
	public static WebElement telephone_RS(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[2]"))).click().build().perform();

		element = driver.findElement(By.id("ctl00_cphMainContent_div52"));
		return element;
	}
	public static WebElement CVS(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[2]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_HyperLink22']"));
		return element;
	}
	public static WebElement SWSSP(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[2]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_HyperLink10']"));
		return element;
	}
	public static WebElement egencia_FI(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[2]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_HyperLink21']"));
		return element;
	}
	public static WebElement expense_Tool(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[3]"))).click().build().perform();

		element = driver.findElement(By.id("ctl00_cphMainContent_lnkExpenseTool"));
		return element;
	}
	public static WebElement cTWK(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[3]"))).click().build().perform();

		element = driver.findElement(By.id("ctl00_cphMainContent_lnkWeKare1"));
		return element;
	}
	public static WebElement shift_Allowance(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[3]"))).click().build().perform();

		element = driver.findElement(By.id("ctl00_cphMainContent_hypShiftEntry"));
		return element;
	}
	public static WebElement thor(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[3]"))).click().build().perform();

		element = driver.findElement(By.id("ctl00_cphMainContent_HyperLink19"));
		return element;
	}
	public static WebElement sCRS(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[3]"))).click().build().perform();

		element = driver.findElement(By.id("ctl00_cphMainContent_lnkSCRT"));
		return element;
	}
	public static WebElement excelity(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[3]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_HyperLink20']"));
		return element;
	}
	public static WebElement POS(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[3]"))).click().build().perform();

		element = driver.findElement(By.id("ctl00_cphMainContent_lnkPo"));
		return element;
	}
	public static WebElement fEAM(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[3]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_lnkForex']"));
		return element;
	}
	public static WebElement webCollect(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[3]"))).click().build().perform();

		element = driver.findElement(By.id("ctl00_cphMainContent_lnlWebColect"));
		return element;
	}
	public static WebElement gMP(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();

		element = driver.findElement(By.id("ctl00_cphMainContent_HyperLink15"));
		return element;
	}
	public static WebElement mPMD(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();

		element = driver.findElement(By.id("ctl00_cphMainContent_lnkMyPMD"));
		return element;
	}
	public static WebElement learningPortal(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_lnkLnC']"));
		return element;
	}
	public static WebElement employees_Retagging(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_lnkAttributeTagging']"));
		return element;
	}
	public static WebElement recruitment(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_lnkRecruit1']"));
		return element;
	}
	public static WebElement empulse(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();

		element = driver.findElement(By.id("ctl00_cphMainContent_lnkExpenseTool"));
		return element;
	}
	public static WebElement lms(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();
		element = driver.findElement(By.xpath("//*[@id=\"ctl00_cphMainContent_hplnk_LMS\"]"));
		return element;
	}
	public static WebElement r2d2(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_lnkRmg']" ));
		return element;
	}
	public static WebElement aIMS(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();

		element = driver.findElement(By.xpath("  //*[@id='ctl00_cphMainContent_lnkAIMs']"));
		return element;
	}
	public static WebElement eCMS(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_HyperLink3']"));
		return element;
	}
	public static WebElement wedding_Gift(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_Image1']"));
		return element;
	}
	public static WebElement career_Framework(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_Image5']"));
		return element;
	}
	public static WebElement rewards_r(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();

		element = driver.findElement(By.xpath("*[@id='ctl00_cphMainContent_ImgRewards']"));
		return element;
	}

	public static WebElement employee_h(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_HyperLink12']"));
		return element;
	}
	public static WebElement my_benefits(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_hplnk_mybenifits']"));
		return element;
	}
	public static WebElement visitor_ms(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_HyperLink41']"));
		return element;
	}
	public static WebElement mobility(WebDriver driver){
		action = new Actions(driver);
		WebElement we = driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul"));
		action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='TabbedPanels1']/ul/li[4]"))).click().build().perform();

		element = driver.findElement(By.xpath("//*[@id='ctl00_cphMainContent_HyperLink13']"));
		return element;
	}
}